﻿using System;

namespace MDK13_01__1
{
    class Program
    {
        static void Main(string[] args)
        {
            MyNode node = new MyNode().CreateDefaulNode();
            node.Show();
            node.AddElemLeft(2);
            node.Show();
            Console.WriteLine(node.Search(node.Head.Value).Value);
            node.Delete(node.Head.Next);
            node.Show();
            node.Clear();
            node.Show();
        }
    }
    class Node
    {

        public int Value { get; set; }
        public Node Next { get; set; }
        public Node Previous { get; set; }
        public Node(int value)
        {
            Value = value;
        }
    }
    class MyNode
    {
        public Node Head = null;
        public Node Current = null;
        public Node Tail = null;
        public MyNode() { }

        public void AddElemFirts(int value)
        {
            Node temp = new Node(value);
            if (Head == null)
            {
                Head = temp;
            }
            else
            {
                temp.Next = Head;
                Head = temp;
            }
        }

        public void AddElemLeft(int value)
        {
            Node node = new Node(value);
            if (Head == null)
            {
                Head = node;
                Head.Next = node;
                Head.Previous = node;
                Tail = Head.Previous;
            }
            else
            {
                node.Previous = Head.Previous;
                node.Next = Head;
                Tail.Previous.Next = node;
                Tail.Previous = node;
            }


        }
        public void Show()
        {
            Console.WriteLine("Элементы:");
            Node temp = Head;
            do
            {
                {
                    temp = temp.Next;
                    Console.WriteLine(temp.Value);
                }
            }
            while (temp != Tail);
            
        }
        public Node Search(int value)
        {
            Console.WriteLine($"Поиск {value}");
            Node temp = Head;
            while (temp != null)
            {
                if (temp.Value == value)
                    return temp;
                temp = temp.Next;
            }
            return null;
        }
        public void Delete(Node delete)
        {
            Console.WriteLine($"Удаление {delete.Value}");
            if (Head == delete)
            {
                Head = Head.Next;
            }
            else
            {
                Node temp = Head;
                while (temp.Next != delete)
                    temp = temp.Next;
                temp.Next = delete.Next;
            }
        }
        public void Clear()
        {
            Console.WriteLine("Очищение списка");
            Node temp;
            while (Head != null)
            {
                temp = Head.Next;
                Head = temp;
            }
        }
        public MyNode CreateDefaulNode()
        {
            Random rnd = new Random();
            MyNode node = new MyNode();
            for (int i = 0; i <= 10; i++)
                node.AddElemLeft(rnd.Next(0, 2000));
            return node;
        }
    }
}
