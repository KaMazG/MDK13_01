﻿using System;

namespace MDK13_01__1
{
    class Program
    {
        static void Main(string[] args)
        {
            MyStack node = new MyStack().CreateDefaulNode();
            node.Show();
            node.Add(2);
            node.Show();
            Console.WriteLine(node.Search(node.Head.Value).Value);
            Console.WriteLine(node.SearchMin());
            node.Delete();
            node.Show();
            node.Clear();
            node.Show();
        }
    }
    class Node
    {

        public int Value { get; set; }
        public Node Next { get; set; }
        public Node(int value)
        {
            Value = value;
        }
    }
    class MyStack
    {
        public Node Head = null;
        public MyStack() { }

        public void Add(int value)
        {
            Node node = new Node(value);
            node.Next = Head;
            Head = node;
        }

        
        public void Show()
        {
            Console.WriteLine("Элементы:");
            if (Head == null)
                Console.WriteLine("Стек пуст");
            else
            {
                Node temp = Head;
                while (temp.Next != null)
                {
                    Console.WriteLine(temp.Value);
                    temp = temp.Next;
                }
            }
            

        }
        public Node Search(int value)
        {
            Console.WriteLine($"Поиск {value}");
            Node temp = Head;
            while (temp != null)
            {
                if (temp.Value == value)
                    return temp;
                temp = temp.Next;
            }
            return null;
        }
        public int SearchMin()
        {
            Console.WriteLine("Поиск минимального:");
            Node temp = Head;
            int min = int.MaxValue;
            while(temp != null)
            {
                if (min > temp.Value)
                    min = temp.Value;
                temp = temp.Next;
            }
            return min;
        }
        public void Delete()
        {
            Console.WriteLine($"Удаление верхнего элемента");
            Head = Head.Next;
        }
        public void Clear()
        {
            Console.WriteLine("Очищение списка");
            Head = null;
        }
        public MyStack CreateDefaulNode()
        {
            Random rnd = new Random();
            MyStack node = new MyStack();
            for (int i = 0; i <= 10; i++)
                node.Add(rnd.Next(0, 2000));
            return node;
        }
    }
}
